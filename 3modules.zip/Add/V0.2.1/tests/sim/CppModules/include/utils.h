#pragma once
#include <armadillo>
#include <iostream>
#include <fstream>
#include <cmath> // Include the header file for the exp function
#include <vector>
#include <array>
#include <random>
#include <algorithm>
#include "config.h"
#include "QuBLAS.h"

using namespace arma;

inline const cx_mat normalize(const cx_mat& M) {
    return M / norm(M, "fro");
}

inline const cx_mat blkdiag(const std::vector<cx_mat>& matrices) {
    size_t rows = 0, cols = 0;
    for (const auto& matrix : matrices) {
        rows += matrix.n_rows;
        cols += matrix.n_cols;
    }
    cx_mat result(rows, cols, fill::zeros);
    size_t row_current = 0, col_current = 0;
    for (const auto& matrix : matrices) {
        result.submat(row_current, col_current, row_current + matrix.n_rows - 1, col_current + matrix.n_cols - 1) = matrix;
        row_current += matrix.n_rows;
        col_current += matrix.n_cols;
    }
    return result;
}

namespace Quma {
    /**
    * @brief Converts an Armadillo matrix to a QuBLAS matrix.
    * @example arma2Qu(Q, A);
    */
    inline void arma2Qu(auto& Q, const auto &A)
    {
        for (int i = 0; i < A.n_elem; i++)
        {
            Q[i] = A(i);
        }
    }

    /**
    * @brief Converts an Armadillo matrix to a QuBLAS matrix. Note that the full type of the QuBLAS matrix must be provided.
    * @example using mat_t = Qu<dim<3,3>,intBits<3>,fracBits<4>>;
    *          auto res = arma2Qu<mat_t>(QuMat);
    */
    template<typename QuT>
    inline auto arma2Qu(const auto &A)
    {
        QuT Q;
        for (int i = 0; i < A.n_elem; i++)
        {
            Q[i] = A(i);
        }
    }

    /**
    * @brief Converts an QuBLAS matrix to an Armadillo matrix.
    * @example Qu2arma(A, Q);
    */
    inline void Qu2arma(auto& A, const auto &Q)
    {
        for (int i = 0; i < A.n_elem; i++)
        {
            A(i) = Q[i].toDouble();
        }
    }

    /**
    * @brief Converts an QuBLAS matrix to an Armadillo matrix. Only works for 1D, 2D and 3D matrices.
    * @example auto res = Qu2arma(Q);
    */
    template<size_t...dims, typename...types>
    inline auto Qu2arma(const Qu_s<dim<dims...>, types...> &Q)
    {
        if constexpr (sizeof...(dims) == 1)
        {
            arma::vec A(packIndex<0>(dims...));
            for (int i = 0; i < A.n_elem; i++)
            {
                A(i) = Q[i].toDouble();
            }

            return A;
        }
        else if constexpr (sizeof...(dims) == 2)
        {
            arma::mat A(packIndex<0>(dims...), packIndex<1>(dims...));
            for (int i = 0; i < A.n_elem; i++)
            {
                A(i) = Q[i].toDouble();
            }
            return A;
        }
        else if constexpr (sizeof...(dims) == 3)
        {
            arma::cube A(packIndex<0>(dims...), packIndex<1>(dims...), packIndex<2>(dims...));
            for (int i = 0; i < A.n_elem; i++)
            {
                A(i) = Q[i].toDouble();
            }
            return A;
        }
        else
        {
            static_assert(sizeof...(dims) == 1 || sizeof...(dims) == 2 || sizeof...(dims) == 3, "dims must be 1, 2 or 3");
        }
    }

    /**
    * @brief Find Unique Elements of Qu Mat or Vec
    * @example auto res = unique(Q);
    */
    template<typename type, size_t...dims>
    inline auto unique(const Qu_s<dim<dims...>, type>& Q) {
        std::vector<type> unique;
        for (int i = 0; i < Q.size; i++)
        {
            if (std::find(unique.begin(), unique.end(), Q[i]) == unique.end())
            {
                unique.push_back(Q[i]);
            }
        }
        return unique;
    }

    /**
    * @brief Find Unique Elements of vectors
    * @example auto res = unique(v)
    */
    template <typename type>
    inline auto unique(const std::vector<type>& v) {
        std::vector<type> unique;
        for (int i = 0; i < v.size(); i++)
        {
            if (std::find(unique.begin(), unique.end(), v[i]) == unique.end())
            {
                unique.push_back(v[i]);
            }
        }
        return unique;
    }

    /**
    * @brief Index Matrix by set
    * @example index(A, Q, set) 
    */
    template<typename type>
    inline void index(auto& A, const auto& Q, const std::vector<type>& set) {
        for (int i = 0; i < Q.size; i++) {
            bool flag = false;
            for (int j = 0; j < set.size(); j++) {
                if (Q[i] == set[j]) {
                    A[i] = j;
                    flag = true;
                }
            }
            if (!flag) {
                // raise error
                std::cout << "Error: Element not found in set" << std::endl;
            }
        }
    }

    /**
    * @brief Fill Qu matrix / vector by value
    * @example fill(Q, 1)
    */
    template<typename type, size_t...dims>
    inline void fill(Qu_s<dim<dims...>, type> &Q, const int value) {
        for (int i = 0; i < Q.size; i++) {
            Q[i] = value;
        }
    }

    template<typename type, size_t...dims>
    inline int argmax(const Qu_s<dim<dims...>, type> &Q) {
        int n_layer = std::ceil(std::log2(Q.size));
        std::vector<int> indices(Q.size);
        for (int i = 0; i < Q.size; i++) {
            indices[i] = i;
        }
        for (int l = 0; l < n_layer; l++) {
            int step = 1 << (l + 1); // 2^{l + 1}
            for (int i = 0; i < Q.size; i += step) {
                if (Q[indices[i]] < Q[indices[i + step / 2]]) {
                    indices[i] = indices[i + step / 2];
                }
                else {
                    indices[i] = indices[i];
                }
            }
        }
        return indices[0];
    }
}

namespace Algorithm {

    template <size_t dim_M, size_t dim_V, size_t par_V, typename fxp_M, typename fxp_V, typename fxp_M_V, typename fxp_O>
    inline void fxp_M2V (
        const Qu<dim<dim_V>, fxp_V>& op_V_real,
        const Qu<dim<dim_V>, fxp_V>& op_V_imag,
        const Qu<dim<dim_M, dim_V>, fxp_M>& op_M_real,
        const Qu<dim<dim_M, dim_V>, fxp_M>& op_M_imag,
        Qu<dim<dim_M>, fxp_O>& op_O_real,
        Qu<dim<dim_M>, fxp_O>& op_O_imag,
        const size_t max_cnt,
        const bool if_last
    ) {
        // constexpr int stg_V = (dim_V + par_V - 1) / par_V;  // std::ceil(dim_V / par_V);
        // set up monitors
        static std::ofstream f_a_plus_b("../Comparison_Files/a_plus_b.txt");                static std::ofstream df_a_plus_b("../Decimal_Comparison/a_plus_b.txt");
        static std::ofstream f_b_minus_a("../Comparison_Files/b_minus_a.txt");              static std::ofstream df_b_minus_a("../Decimal_Comparison/b_minus_a.txt");
        static std::ofstream f_c_plus_d("../Comparison_Files/c_plus_d.txt");                static std::ofstream df_c_plus_d("../Decimal_Comparison/c_plus_d.txt");
        static std::ofstream f_A("../Comparison_Files/A.txt");                              static std::ofstream df_A("../Decimal_Comparison/A.txt");
        static std::ofstream f_B("../Comparison_Files/B.txt");                              static std::ofstream df_B("../Decimal_Comparison/B.txt");
        static std::ofstream f_C("../Comparison_Files/C.txt");                              static std::ofstream df_C("../Decimal_Comparison/C.txt");
        static std::ofstream f_M_V_real("../Comparison_Files/M_V_real.txt");                static std::ofstream df_M_V_real("../Decimal_Comparison/M_V_real.txt");
        static std::ofstream f_M_V_imag("../Comparison_Files/M_V_imag.txt");                static std::ofstream df_M_V_imag("../Decimal_Comparison/M_V_imag.txt");
        static std::ofstream f_op_O_real_tmp("../Comparison_Files/op_O_real_tmp.txt");      static std::ofstream df_op_O_real_tmp("../Decimal_Comparison/op_O_real_tmp.txt");
        static std::ofstream f_op_O_imag_tmp("../Comparison_Files/op_O_imag_tmp.txt");      static std::ofstream df_op_O_imag_tmp("../Decimal_Comparison/op_O_imag_tmp.txt");

        // Calculate M2V
        Quma::fill(op_O_real, 0); Quma::fill(op_O_imag, 0);
        for (uword stg = 0; stg < max_cnt; stg++) {
            // for each stage
            std::array<Qu<dim<par_V>, fxp_M_V>, dim_M> M_V_real, M_V_imag;
            for (uword par = 0; par < par_V; par++) {
                // for each par
                uword idx = stg*par_V + par;
                if (idx < dim_V) {
                    const auto a_plus_b = Qadd<fxp::AugQu<1, fxp_V>>(op_V_real[idx], op_V_imag[idx]);
                    const auto b_minus_a = Qsub<fxp::AugQu<1, fxp_V>>(op_V_imag[idx], op_V_real[idx]);
                    if (verify::monitor_enabled) {
                        f_a_plus_b << a_plus_b.toString(); df_a_plus_b << a_plus_b.toDouble() << " ";
                        f_b_minus_a << b_minus_a.toString(); df_b_minus_a << b_minus_a.toDouble() << " ";
                    }
                    for (uword m = 0; m < dim_M; m++) {
                        // for each element in M(:, idx)
                        // Calculate M(m, idx) * V(idx)
                        const auto c_plus_d = Qadd<fxp::AugQu<1, fxp_M>>(op_M_real[m, idx], op_M_imag[m, idx]);
                        const auto A = Qmul<fxp_M_V>(a_plus_b, op_M_real[m, idx]);
                        const auto B = Qmul<fxp_M_V>(c_plus_d, op_V_imag[idx]);
                        const auto C = Qmul<fxp_M_V>(b_minus_a, op_M_imag[m, idx]);
                        M_V_real[m][par] = Qsub<fxp_M_V>(A, B);
                        M_V_imag[m][par] = Qsub<fxp_M_V>(B, C);
                        if (verify::monitor_enabled) {
                            f_c_plus_d << c_plus_d.toString(); df_c_plus_d << c_plus_d.toDouble() << " ";
                            f_A << A.toString(); df_A << A.toDouble() << " ";
                            f_B << B.toString(); df_B << B.toDouble() << " ";
                            f_C << C.toString(); df_C << C.toDouble() << " ";
                            f_M_V_real << M_V_real[m][par].toString(); df_M_V_real << M_V_real[m][par].toDouble() << " ";
                            f_M_V_imag << M_V_imag[m][par].toString(); df_M_V_imag << M_V_imag[m][par].toDouble() << " ";
                        }        
                    }
                }
                else {
                    if (verify::monitor_enabled) {
                        const Qu<fxp::AugQu<1, fxp_V>> a_plus_b = 0;
                        const Qu<fxp::AugQu<1, fxp_V>> b_minus_a = 0;
                        f_a_plus_b << a_plus_b.toString(); df_a_plus_b << a_plus_b.toDouble() << " ";
                        f_b_minus_a << b_minus_a.toString(); df_b_minus_a << b_minus_a.toDouble() << " ";
                    }
                    for (uword m = 0; m < dim_M; m++) {
                        M_V_real[m][par] = 0;
                        M_V_imag[m][par] = 0;
                        if (verify::monitor_enabled) {
                            const Qu<fxp::AugQu<1, fxp_M>> c_plus_d = 0;
                            const Qu<fxp_M_V> A = 0;
                            const Qu<fxp_M_V> B = 0;
                            const Qu<fxp_M_V> C = 0;
                            f_c_plus_d << c_plus_d.toString(); df_c_plus_d << c_plus_d.toDouble() << " ";
                            f_A << A.toString(); df_A << A.toDouble() << " ";
                            f_B << B.toString(); df_B << B.toDouble() << " ";
                            f_C << C.toString(); df_C << C.toDouble() << " ";
                            f_M_V_real << M_V_real[m][par].toString(); df_M_V_real << M_V_real[m][par].toDouble() << " ";
                            f_M_V_imag << M_V_imag[m][par].toString(); df_M_V_imag << M_V_imag[m][par].toDouble() << " ";
                        }
                    }
                }
            }
            // Adder Tree
            Qu<dim<dim_M>, fxp_O> op_O_real_tmp, op_O_imag_tmp;
            for (uword m = 0; m < dim_M; m++) {
                op_O_real_tmp[m] = Qreduce<fxp::TreeQu<par_V, fxp_M_V>>(M_V_real[m]);
                op_O_imag_tmp[m] = Qreduce<fxp::TreeQu<par_V, fxp_M_V>>(M_V_imag[m]);
                if (verify::monitor_enabled) {
                    f_op_O_real_tmp << op_O_real_tmp[m].toString(); df_op_O_real_tmp << op_O_real_tmp[m].toDouble() << " ";
                    f_op_O_imag_tmp << op_O_imag_tmp[m].toString(); df_op_O_imag_tmp << op_O_imag_tmp[m].toDouble() << " ";
                }
            }
            op_O_real = Qadd<fxp_O>(op_O_real, op_O_real_tmp);
            op_O_imag = Qadd<fxp_O>(op_O_imag, op_O_imag_tmp);
            if (verify::monitor_enabled) {
                f_a_plus_b << std::endl; df_a_plus_b << std::endl;
                f_b_minus_a << std::endl; df_b_minus_a << std::endl;
                f_c_plus_d << std::endl; df_c_plus_d << std::endl;
                f_A << std::endl; df_A << std::endl;
                f_B << std::endl; df_B << std::endl;
                f_C << std::endl; df_C << std::endl;
                f_M_V_real << std::endl; df_M_V_real << std::endl;
                f_M_V_imag << std::endl; df_M_V_imag << std::endl;
                f_op_O_real_tmp << std::endl; df_op_O_real_tmp << std::endl;
                f_op_O_imag_tmp << std::endl; df_op_O_imag_tmp << std::endl;
            }            
        }
        if (if_last) {
            // Close Monitor Files
            f_a_plus_b.close(); df_a_plus_b.close();
            f_b_minus_a.close(); df_b_minus_a.close();
            f_c_plus_d.close(); df_c_plus_d.close();
            f_A.close(); df_A.close();
            f_B.close(); df_B.close();
            f_C.close(); df_C.close();
            f_M_V_real.close(); df_M_V_real.close();
            f_M_V_imag.close(); df_M_V_imag.close();
            f_op_O_real_tmp.close(); df_op_O_real_tmp.close();
            f_op_O_imag_tmp.close(); df_op_O_imag_tmp.close();
        }
    }
}

namespace Analysis {
    inline const mat Gram(cx_mat A) {
        A = normalise(A, 2, 1);
        const mat G = abs(A*A.t()) - eye(A.n_rows, A.n_rows);
        return G;
    }
    inline const double max_coh(cx_mat A) {
        return Gram(A).max();
    }
    inline const double tot_coh(cx_mat A) {
        return accu(Gram(A));
    }
    inline const double NMSE(const cx_mat& H, const cx_mat& H_hat) {
        return std::pow(norm(H - H_hat, "fro"), 2) / std::pow(norm(H, "fro"), 2);
    }
}
