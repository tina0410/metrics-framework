#include <iostream>
#include <iomanip> // Include the <iomanip> library for setw and left manipulators
// #include <armadillo>
#include <utility>
#include <fstream>
#include <random>
#include "utils.h"

using namespace arma;

size_t randint(size_t N) {
    std::random_device rd; // Obtain a random number from hardware
    std::mt19937 gen(rd()); // Seed the generator
    std::uniform_int_distribution<> distr(1, N); // Define the range
    return distr(gen); // Generate a random number in the range [1, N]
}

int main() {
    Qu<dim<fxp::dim_V>, fxp::V> op_V_real;
    Qu<dim<fxp::dim_V>, fxp::V> op_V_imag;
    Qu<dim<fxp::dim_M, fxp::dim_V>, fxp::M> op_M_real;
    Qu<dim<fxp::dim_M, fxp::dim_V>, fxp::M> op_M_imag;

    std::ofstream f_op_V_real("../Input_Files/op_V_real.txt"); std::ofstream df_op_V_real("../Decimal_Comparison/op_V_real.txt");
    std::ofstream f_op_V_imag("../Input_Files/op_V_imag.txt"); std::ofstream df_op_V_imag("../Decimal_Comparison/op_V_imag.txt");
    std::ofstream f_op_M_real("../Input_Files/op_M_real.txt"); std::ofstream df_op_M_real("../Decimal_Comparison/op_M_real.txt");
    std::ofstream f_op_M_imag("../Input_Files/op_M_imag.txt"); std::ofstream df_op_M_imag("../Decimal_Comparison/op_M_imag.txt");
    const fxp::bit rdy = 1;
    std::ofstream f_rdy("../Input_Files/rdy.txt");
    fxp::cnt max_cnt;
    std::ofstream f_max_cnt("../Input_Files/max_cnt.txt"); std::ofstream df_max_cnt("../Decimal_Comparison/max_cnt.txt");

    Qu<dim<fxp::dim_M>, fxp::O> op_O_real;
    Qu<dim<fxp::dim_M>, fxp::O> op_O_imag;
    std::ofstream f_op_O_real("../Comparison_Files/op_O_real.txt"); std::ofstream df_op_O_real("../Decimal_Comparison/op_O_real.txt");
    std::ofstream f_op_O_imag("../Comparison_Files/op_O_imag.txt"); std::ofstream df_op_O_imag("../Decimal_Comparison/op_O_imag.txt");

    for (size_t frame = 0; frame < verify::N_Frames; frame++) {
        // Randomly Generate Dimension
        // size_t ef_dim_V = randint(fxp::dim_V); // effective dimensions
        // const size_t ef_dim_V = fxp::dim_V;
        const size_t ef_dim_V = 6;
        const size_t ef_N_stg = (ef_dim_V + fxp::par_V - 1) / fxp::par_V;
        max_cnt = ef_N_stg - 1; // effective stages (0 is 1 stage)
        // Randomly Generate Input
        for (size_t v = 0; v < ef_dim_V; v++) {
            op_V_real[v].fill();
            op_V_imag[v].fill();
            for (size_t m = 0; m < fxp::dim_M; m++) {
                op_M_real[m, v].fill();
                op_M_imag[m, v].fill();
            }
        }
        for (size_t v = ef_dim_V; v < fxp::dim_V; v++) {
            op_V_real[v] = 0;
            op_V_imag[v] = 0;
            for (size_t m = 0; m < fxp::dim_M; m++) {
                op_M_real[m, v] = 0;
                op_M_imag[m, v] = 0;
            }
        }
        // Calculate Comparison Results
        Algorithm::fxp_M2V<fxp::dim_M, fxp::dim_V, fxp::par_V, fxp::M, fxp::V, fxp::M_V, fxp::O>(op_V_real, op_V_imag, op_M_real, op_M_imag, op_O_real, op_O_imag, ef_N_stg, (frame == verify::N_Frames-1));
        // Write to File
        for (size_t stg = 0; stg < ef_N_stg; stg++) {
            // for each stage
            for (size_t par = fxp::par_V; par > 0; par--) {
                size_t idx = stg * fxp::par_V + (par - 1);
                if (idx < fxp::dim_V) {
                    // y input 
                    f_op_V_real << op_V_real[idx].toString(); df_op_V_real << op_V_real[idx].toDouble() << " ";
                    f_op_V_imag << op_V_imag[idx].toString(); df_op_V_imag << op_V_imag[idx].toDouble() << " ";
                    // Q input
                    for (size_t m = fxp::dim_M; m > 0; m--) {
                        f_op_M_real << op_M_real[m-1, idx].toString(); df_op_M_real << op_M_real[m-1, idx].toDouble() << " ";
                        f_op_M_imag << op_M_imag[m-1, idx].toString(); df_op_M_imag << op_M_imag[m-1, idx].toDouble() << " ";
                    }
                }
                else {
                    // y input 
                    const Qu<fxp::V> zero = 0;
                    f_op_V_real << zero.toString(); df_op_V_real << zero.toDouble() << " ";
                    f_op_V_imag << zero.toString(); df_op_V_imag << zero.toDouble() << " ";
                    // Q input
                    for (size_t m = fxp::dim_M; m > 0; m--) {
                        f_op_M_real << zero.toString(); df_op_M_real << zero.toDouble() << " ";
                        f_op_M_imag << zero.toString(); df_op_M_imag << zero.toDouble() << " ";
                    }
                }
            }
            f_op_V_real << std::endl; df_op_V_real << std::endl;
            f_op_V_imag << std::endl; df_op_V_imag << std::endl;
            f_op_M_real << std::endl; df_op_M_real << std::endl;
            f_op_M_imag << std::endl; df_op_M_imag << std::endl;
            f_rdy << rdy.toString() << std::endl;
            f_max_cnt << max_cnt.toString() << std::endl; df_max_cnt << max_cnt.toDouble() << std::endl;
        }            
        // QHy output
        for (size_t m = fxp::dim_M; m > 0; m--) {
            f_op_O_real << op_O_real[m-1].toString(); df_op_O_real << op_O_real[m-1].toDouble();
            f_op_O_imag << op_O_imag[m-1].toString(); df_op_O_imag << op_O_imag[m-1].toDouble();
        }
        f_op_O_real << std::endl; df_op_O_real << std::endl;
        f_op_O_imag << std::endl; df_op_O_imag << std::endl;
    }

    // Close Files
    f_op_V_real.close(); df_op_V_real.close();
    f_op_V_imag.close(); df_op_V_imag.close();
    f_op_M_real.close(); df_op_M_real.close();
    f_op_M_imag.close(); df_op_M_imag.close();
    f_rdy.close();
    f_max_cnt.close(); df_max_cnt.close();
    f_op_O_real.close(); df_op_O_real.close();
    f_op_O_imag.close(); df_op_O_imag.close();
}